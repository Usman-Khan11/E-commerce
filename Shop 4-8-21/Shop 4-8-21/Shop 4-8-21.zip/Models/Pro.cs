﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shop_4_8_21.Models
{
    public class Pro
    {
        public List<tbl_product> Products { get; set; }

        public Pager Pager { get; set; }
       
    }
}